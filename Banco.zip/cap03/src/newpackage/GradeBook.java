package newpackage;
public class GradeBook {
    public void displayMessage(String courseName){
        System.out.println("Welcome to GradeBook for "+courseName);
    }
    
    public void mostraMensagens(String m1,String m2){
        System.out.println(m1+" "+m2);
    }
}
