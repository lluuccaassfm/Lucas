package newpackage;

import java.util.Scanner;

public class GradeBookTest {
    public static void main(String[] args) {
        
        GradeBook myGradeBook = new GradeBook();
        Scanner leia = new Scanner(System.in);
        
        System.out.println("Please enter the couser name:");
        //String nameCourse = imput.nextLine();
        String nameCourse = leia.nextLine();
        System.out.println();
        
        myGradeBook.displayMessage("Aula Java");
        myGradeBook.mostraMensagens("Bem-Vindo ao Diário",nameCourse);

    }

    
}
