package ContaCorrente;

import java.util.Scanner;

public class ContaTest {
    public static void main(String[] args) {
        
        
           
      Conta conta1 = new Conta (50.00 ); // Cria objeto conta1 da classe Conta e chama construtor
      Conta conta2 = new Conta (-7.53 ); // Instancia objeto conta2 da classe Conta e chama construtor
        System.out.printf ( "conta1, saldo R$ %.2f\n", conta1.getSaldo ( ) );   // Exibe o saldo das duas contas.
        System.out.printf ( "conta2, saldo R$ %.2f\n", conta2.getSaldo ( ) );   // Mostra com 2 casas decimais.
        Scanner leia = new Scanner ( System.in ); // Cria (instancia) objeto leia da classe Scanner. Usado pra ler
      
      double valorDeposito;                                 // Declara a variável valorDeposito do tipo double.
      System.out.print ( "\nValor do depósito da conta1: " );                   // Mensagem antes da digitação.
      valorDeposito = leia.nextDouble ( );         // Lê um valor double, o usuário entra com o valor do depósito.
      System.out.printf ( "Foi depositado R$ %.2f na conta1.\n", valorDeposito );  // sout  + <tab>   ( atalho )
      // nomeObjeto.nomeMetodo ( argumento );  ( Modelo pra chamar um método público da classe Java )
      conta1.credito ( valorDeposito );    // Chama o método credito passando o valor do depósito na conta1.
     
        System.out.printf ( "Conta1, saldo R$ %.2f\n", conta1.getSaldo ( ) );   // Exibe o saldo das duas contas.
        System.out.printf ( "Conta2, saldo R$ %.2f\n", conta2.getSaldo ( ) );   // Chama o método getSaldo.
     
      System.out.print( "\nValor do depósito da conta2: " );                         // Mensagem antes da digitação.
      valorDeposito = leia.nextDouble ( );      // Lê um valor double, o usuário entra com o valor do depósito.
      System.out.printf ( "Foi depositado R$ %.2f na conta2.\n", valorDeposito ); // Msg confirmando depósito.
      conta2.credito ( valorDeposito );     // Chama o método credito passando o valor do depósito na conta2
        System.out.printf ( "Conta1, saldo R$ %.2f\n", conta1.getSaldo ( ) );   // Exibe o saldo das duas contas.
        System.out.printf ( "Conta2, saldo R$ %.2f\n", conta2.getSaldo ( ) );   // Chama o método getSaldo.
      
    //ALTERAÇÕES  
      double vlSaque;
        System.out.print("\nValor a ser retirado (Conta1): ");
        vlSaque=leia.nextDouble();
            if(vlSaque<=conta1.getSaldo())
                conta1.debito(vlSaque);
            else
                System.out.println("\n***Quantia de débito excedeu o saldo da conta***");
         
         System.out.printf ( "Conta1, saldo R$ %.2f\n", conta1.getSaldo ( ) );   // Exibe o saldo das duas contas.
         System.out.printf ( "Conta2, saldo R$ %.2f\n", conta2.getSaldo ( ) );   // Chama o método getSaldo.
        
   
    Conta conta3 = new Conta(100.00,"Lucas");
        System.out.printf("Conta3, saldo R$ %.2f\n",conta3.getSaldo());
                
        conta3.mostraDados();
        
        System.out.println("\nValor do Cheque especial(conta1): ");
        double chequeEspecial=leia.nextDouble();
        conta1.setChequeEspecial(chequeEspecial);
        System.out.println("Valor do Cheque especial(conta2): ");
        chequeEspecial=leia.nextDouble();
        conta2.setChequeEspecial(chequeEspecial);
        System.out.println("Valor do Cheque especial(conta3): ");
        chequeEspecial=leia.nextDouble();
        conta3.setChequeEspecial(chequeEspecial);
        
        int op=0;
        while(op!=4){
        System.out.println("Bem-Vindo ao BancoJAVA\n*** MENU ***\n1- Consulta\n2- Saque\n3- Depósito\n4- sair");
        op=leia.nextInt();
        switch (op){
            case 1:
                int c;
                System.out.println("*** MENU ***\n- Consulta\nEscolha a Conta: 1 - 2 - 3");
                c=leia.nextInt();
                switch(c){
                    case 1: System.out.println("\nSaldo(conta1): "+conta1.getSaldo()+"\nCheque Especial: "+conta1.getChequeEspecial()+"\n");break;
                    case 2: System.out.println("\nSaldo(conta2): "+conta2.getSaldo()+"\nCheque Especial: "+conta2.getChequeEspecial()+"\n");break;
                    case 3: System.out.println("\nSaldo(conta3): "+conta3.getSaldo()+"\nCheque Especial: "+conta3.getChequeEspecial()+"\n");break;
                }
                break;
            case 2:
                System.out.println("*** MENU ***\n- Consulta\nEscolha a Conta: 1 - 2 - 3");
                c=leia.nextInt();
                switch(c){
                    case 1: 
                        System.out.print("\nValor a ser retirado (Conta1): ");
                        vlSaque=leia.nextDouble();
                        conta1.debito(vlSaque);
                        break;
                    case 2: 
                        System.out.print("\nValor a ser retirado (Conta2): ");
                        vlSaque=leia.nextDouble();
                        conta2.debito(vlSaque);
                        break;
                    case 3: 
                        System.out.print("\nValor a ser retirado (Conta3): ");
                        vlSaque=leia.nextDouble();
                        conta3.debito(vlSaque);
                        break;
                }
             break;   
             
            case 3: 
                System.out.println("*** MENU ***\n- Consulta\nEscolha a Conta: 1 - 2 - 3");
                c=leia.nextInt();
                switch(c){
                    case 1:  
                        System.out.print ( "\nValor do depósito da conta1: " ); 
                        valorDeposito = leia.nextDouble ( );
                        conta1.credito ( valorDeposito );
                        break;
                    case 2: 
                        System.out.print ( "\nValor do depósito da conta2: " ); 
                        valorDeposito = leia.nextDouble ( );
                        conta2.credito ( valorDeposito );
                        break;
                    case 3: 
                        System.out.print ( "\nValor do depósito da conta3: " ); 
                        valorDeposito = leia.nextDouble ( );
                        conta3.credito ( valorDeposito );
                        break;
                }
                break;
                
        }
        }
    }
}
    

