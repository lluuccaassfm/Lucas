package ContaCorrente;
public class Conta {
    //Atributos
    private double saldo;
    private String nomeCorrentista;
    private String nrConta;
    private double chequeEspecial;
    
    //Construtores
    public Conta(double SaldoInicial){
        if(SaldoInicial>0)
            saldo = SaldoInicial;
    }
    
    public Conta(double SaldoInicial, String nome){
        if(SaldoInicial>0)
            saldo = SaldoInicial;
        
            nomeCorrentista = nome;
    }
    public Conta(double SaldoInicial, String nome, String numeroConta){
        if(SaldoInicial>0)
            saldo = SaldoInicial;
        
            nomeCorrentista = nome;
            nrConta = numeroConta;
    }
    //Métodos
    public void credito (double montante){
        
        saldo = saldo + montante;
        
    }
    
    public void debito (double vlSaque){
        if(vlSaque<=saldo)
            saldo = saldo - vlSaque;
        else
            if(vlSaque<=saldo+chequeEspecial){
                chequeEspecial = (saldo + chequeEspecial) - vlSaque;
                saldo =0;
            }else{
                System.out.println(" Impossível realizar o saque");
            }
    }
    public void mostraDados(){
        System.out.printf("Saldo: %.2f\tNome: %s\n",saldo,nomeCorrentista);
    }

    //Get - Set
    public double getSaldo() {
        return saldo;
    }

    public String getNomeCorrentista() {
        return nomeCorrentista;
    }
    public void setNomeCorrentista(String nomeCorrentista) {
        this.nomeCorrentista = nomeCorrentista;
    }

    public String getNrConta() {
        return nrConta;
    }

    public void setNrConta(String nrConta) {
        this.nrConta = nrConta;
    }

    public double getChequeEspecial() {
        return chequeEspecial;
    }

    public void setChequeEspecial(double chequeEspecial) {
        this.chequeEspecial = chequeEspecial;
    }
        
        
}
